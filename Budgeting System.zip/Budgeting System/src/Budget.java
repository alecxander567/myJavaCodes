import java.util.Scanner;
public class Budget {
	
	int thousand, hundred, ten;
	
	 Budget(int thousand, int hundred, int ten){
		this.thousand = thousand;
		this.hundred = hundred;
		this.ten = ten;
	 }
}
